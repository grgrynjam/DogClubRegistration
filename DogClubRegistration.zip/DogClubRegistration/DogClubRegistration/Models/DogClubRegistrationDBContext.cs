﻿using DogClubRegistration.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DogClubRegistration.Models
{
    public class DogClubRegistrationDBContext : DbContext
    {
        public DogClubRegistrationDBContext(DbContextOptions options) : base(options)
        {
                
        }
        public DbSet<Registration> Registration { get; set; }
    }
}
