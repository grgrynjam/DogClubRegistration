﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DogClubRegistration.Models
{
    public class Registration
    {
        [Key]
        public int OwnerId { get; set; }

        [Required(ErrorMessage ="Please input first name")]
        public string FirstName { get; set; }
        
        [Required(ErrorMessage = "Please input surname")]
        public string SurName { get; set; }

        [Required, Range(16, 99)]
        public int Age { get; set; }

        [Required, StringLength(200)]
        public string  Address { get; set; }

        [Required(ErrorMessage = "Please input your dog's name")]
        public string DogName { get; set; }

        [Required(ErrorMessage = "Please input your dog's breed")]
        public string DogBreed { get; set; }
    }
}
